# *summer2021.amazing*

# **By Team Verification**

## DevOps
- Rob Wilson
- Michelle
- Jeroen Soeurt

## Team Amazing
- 

