//**************************************************************
// Settings view model
// Author:
//**************************************************************
import 'package:stacked/stacked.dart';

class SettingsViewModel extends BaseViewModel{

  void initialize(){

  }

  @override
  void dispose() {
    super.dispose();
  }

}