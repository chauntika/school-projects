import 'package:flutter/material.dart';

ThemeData darkTheme = ThemeData(
    primaryColor: Colors.redAccent,
    accentColor: Colors.orangeAccent
);