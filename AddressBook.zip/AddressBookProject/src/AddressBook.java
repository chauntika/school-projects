import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;

public class AddressBook {	
	private String contactFile = "contacts.txt";
	private ArrayList<Contact> contacts;
	
	public AddressBook(){
		// constructor
		contacts = new ArrayList<Contact>();
		contacts = this.loadContacts();
	}
	
	public void showMenu() {
		// method to show menu
		
		Scanner menu = new Scanner(System.in); // initialize scanner object
		
		// menu bar
		System.out.println(" ");
		System.out.println("////////////////////////////");
		System.out.println("MENU OPTIONS");
		System.out.println("____________________________");
		System.out.println("1. - Show Menu Bar\n");
		System.out.println("2. - Display Address Book\n");
		System.out.println("3. - Add Contact\n");
		System.out.println("4. - Update Contact\n");
		System.out.println("5. - Remove Contact\n");
		System.out.println("///////////////////////////");
		
		System.out.println("Enter number of menu option desired: ");
				
		String menuOption = menu.nextLine();  // user's choice
		
		// actions for different menu options
		switch (menuOption)	{
			case "1" :
				showMenu();
				break;
			case "2":
				displayAddressBook(); // add contact
				break;
			case "3":
				addContact(); // add contact
				break;
			case "4":
				System.out.println("Enter id number of contact: "); // ask user for id of contact
				
				Integer id = menu.nextInt(); // assign entered id to id variable
				
				// loop through contacts to search for contact to update
				for (int x=0; x < contacts.size(); x++)
					if (contacts.get(x).getID().equals(id)) {
						Contact contact1= new Contact(id, contacts.get(x).getContactName(), contacts.get(x).getStreet(),
								contacts.get(x).getCity(), contacts.get(x).getState(), contacts.get(x).getZip(),
								contacts.get(x).getPhone());
							
						updateContact(contact1); // update contact
					}
			case "5":
				System.out.println("Enter id number of contact: "); // ask user for id of contact
					
				Integer id2 = menu.nextInt(); // assign entered id to id variable
					
				if (id2 != null) 
					removeContact(id2); // remove contact
				
				break;
			default: System.out.println("Choose 1-4."); // add contact;
			System.out.println("Enter number of menu option desired: ");
			menuOption = menu.nextLine();
		}
			menu.close(); // close scanner
	}
	
	public void displayAddressBook() {
		// method to display address book
		// print header
		System.out.println("-----------------------------------------------------------------------\n");
		System.out.println("Address Book\n");
		System.out.println("-----------------------------------------------------------------------\n\n");
		
		if (contacts.size() <= 0) {
			System.out.println("No contacts found.");
		} else {
		for (int i=0; i < contacts.size(); i++)
			System.out.println("ID: " + contacts.get(i).getID() +
				" Name: " + contacts.get(i).getContactName() + " Street: " + contacts.get(i).getStreet() +
				" City: " + contacts.get(i).getCity() + " State: " + " Zip: " + contacts.get(i).getZip() +
				" Phone: " + contacts.get(i).getPhone() + "\n");
		}
		System.out.println("-----------------------------------------------------------------------\n");
		showMenu(); // display menu
	}
	
	public ArrayList<Contact> loadContacts() {
		// method to retrieve array of contacts
		String starterMessage = "Loading contacts....."; // starter message
		System.out.println(starterMessage); // display loading contacts message
		
		// create new arraylist to hold contact objects
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		
		// variable to represent next line in file
		String fileStr="";
		
		try {// try to read contents of file
			File file = new File(contactFile);
			if (file.createNewFile() || file.length() == 0) {
				System.out.println("No contacts in file.");
			} else {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			while ((fileStr = reader.readLine()) != null) {
					Contact contact = new Contact(fileStr);
					contactList.add(contact); // add contact object to arraylist
			}// complete while statement	
			
			reader.close(); // close buffered reader
			
			contacts = contactList; // assign parsed contacts to contact arraylist
			}
		} // complete try statement		
		catch (IOException e) {
			System.err.println("No contacts available.");
		}
		return contacts;			
	}
	
	public void addContact() {
		// method to add contact
		// get input from user
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter contact id (1-99): "); // ask user to input name	    
		Integer id = Integer.parseInt(input.nextLine());// assign input to id variable
	    
		System.out.println("\nEnter contact name: "); // ask user to input name	    
	    String fullName = input.nextLine(); // assign input to name variable
	    
	    System.out.println("\nEnter contact's street name: "); // ask user to input street	    
	    String street = input.nextLine(); // assign input to street variable
	    
	    System.out.println("\nEnter contact's city name: "); // ask user to input city	    
	    String city = input.nextLine(); // assign input to city variable
	    
	    
	    System.out.println("\nEnter contact's state name: "); // ask user to input state
	    String state = input.nextLine();
	    
	    System.out.println("\nEnter contact's zip code: "); // ask user to input zip
	    String zip = input.nextLine();
	    
	    System.out.println("\nEnter contact's phone number (ie. 301-345-9876): "); // ask user to input phone
	    String phone = input.nextLine();
	    
	   
	    
	    // create new contact object from input
	    Contact contact2 = new Contact(id, fullName, street, city, state, zip, phone);
	    
		contacts.add(contact2); // add contact to empty array
		
		System.out.println("Contact added.");
			
		updateFile(); // update contact file		
		
		input.close(); // close scanner	
	}
	
	// update contact
	public void updateContact(Contact contact) {
		// method to update contact
		Contact contact1; // declare new Contact to hold new contact information
		
		for (int i=0; i < contacts.size(); i++)
			// searching for the contact with the provided id number
			if (contacts.get(i).getID().equals(contact.getID())) {
				// assign entered contact info contact object
				contact1 = new Contact(contact.getID(), contact.getContactName(), 
						contact.getStreet(), contact.getCity(), 
						contact.getState(), contact.getZip(),
						contact.getPhone());
				System.out.println("\nCurrent Contact Info:\n");
				System.out.println(contact1.getID() + " " + contact1.getContactName() + " " + contact1.getStreet() +
						" " + contact1.getCity() + " " + contact1.getState() + " " + contact1.getZip() + 
						" " + contact1.getPhone());
				// get input from user
				Scanner updateScan = new Scanner(System.in);

			    System.out.println("Enter updated contact name: "); // ask user to input name
			    
			    String fullName = updateScan.nextLine();	 // assign input to name variable
			    
			    if (fullName == null) { // check if null
			    	System.out.println("\nName cannot be empty. Please enter contact's name: ");
			    	fullName = updateScan.nextLine();
			    }
			    
			    System.out.println("\nEnter updated contact's street name: "); // ask user to input street
			    String street = updateScan.nextLine(); // assign input to street variable
			    
			    if (street == null) { // check if null
			    	 System.out.println("\nStreet cannot be empty. Please enter contact's street name: ");
			    	 street = updateScan.nextLine();
			    } 
			    
			    System.out.println("\nEnter updated contact's city name: "); // ask user to input city			    
			    String city = updateScan.nextLine(); // assign input to city variable
			    
			    
			    System.out.println("\nEnter updated contact's state name: "); // ask user to input state
			    String state = updateScan.nextLine();
			    
			    System.out.println("\nEnter updated contact's zip code: "); // ask user to input zip
			    String zip = updateScan.nextLine();
			    
			    System.out.println("\nEnter updated contact's phone number (ie. 3013459876): "); // ask user to input phone
			    String phone = updateScan.nextLine();
			    
			    // initialize new contact object for updated input data			    
			    Contact contact3 = new Contact(contact1.getID(), fullName.toUpperCase(), 
			    		street.toUpperCase(), city.toUpperCase(), state.toUpperCase(), zip, phone);
				
				contacts.set(i, contact3); // remove old contact information	
				
				// update successful
				System.out.println("\nContact has been updated.");
				
				updateFile(); // update contact file
				
				updateScan.close(); // close scanner				
				
			} else {// print error message if contact is not found
				System.out.println("Contact not found.");
			}
	}
	
	// update/save to file
	public void updateFile() {
		// method to save contacts to file
		FileWriter update = null;
		try {
			
			// create or override contacts file
			update = new FileWriter(contactFile, false);
						
			// loop through contact list and add to file
			for (int i = 0; i < contacts.size(); i++)
				// write each contact object to file using toString() method
				update.write(contacts.get(i).toString() + "\n");
			
			update.close(); // close file
			
			displayAddressBook(); // display updated address book
		} catch (IOException e) {// print error message if file couldn't update
			System.out.println(e);			
		} // end try/catch
	}
	
	// remove contact
	public void removeContact(Integer id) {
		// method to remove contact
		for (int i=0; i < contacts.size(); i++)
			
			// searching for the contact with the provided id number
			if (contacts.get(i).getID().equals(id)) {
				
				contacts.remove(i); // remove contact
				
				System.out.println("Contact has been removed."); // removal success
				
				updateFile(); // update contact file	
			} 
	}
	
	// get contacts in contact array
	public ArrayList<Contact> getContacts(){
		ArrayList<Contact> contactList = new ArrayList<Contact>(); // empty list for clone
		for (Contact cont : contacts) {
		contactList.add(cont);
		}
		return contacts = contactList;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AddressBook ab = new AddressBook();
		ab.showMenu();

	}

}