import org.apache.commons.lang3.StringUtils;

public class Contact {
	
	private Integer id; // contact id number
	private String contactName; // contact name
	private String street; // contact street address
	private String city; // contact city
	private String state; // contact state
	private String zip; // contact zip
	private String phone; // contact phone number
	
	public Contact(Integer id, String contactName, String street, String city, String state, 
			String zip, String phone) {
		
		this.id = id; // assign entered id to id		
		this.contactName = contactName; // assign entered name to name attribute
		this.street = street; // assign entered street to street attribute
		this.city = city; // assign entered city to city attribute
		this.state = state; // assigned entered state to state attribute
		this.zip = zip; // assign entered zip to zip attribute
		this.phone = phone; // assign entered phone to phone attribute
	}
	
	public Contact(String line) {
		try {
			// assign attributes with data from string
			// temporary string to hold id number
			String tempID = StringUtils.substringBetween(line, "<id>", "</id>");
			id =  Integer.parseInt(tempID); // convert string id into Integer id
			contactName = StringUtils.substringBetween(line, "<name>", "</name>");  
			street = StringUtils.substringBetween(line, "<street>", "</street>");  
			city = StringUtils.substringBetween(line, "<city>", "</city>");  
			state = StringUtils.substringBetween(line, "<state>", "</state>");  
			zip = StringUtils.substringBetween(line, "<zip>", "</zip>");  
			phone = StringUtils.substringBetween(line, "<phone>", "</phone>"); 
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public Integer getID() {
		return id;
	}
	
	public String getContactName() {
		// getter method for contact name
		return contactName;
	}
	
	public String getStreet() {
		// getter method for contact street
		return street;
	}
	
	public String getCity() {
		// getter method for contact city
		return city;
	}
	
	public String getState() {
		// getter method for contact state
		return state;
	}
	
	public String getZip() {
		// getter method for contact zip
		return zip;
	}
	
	public String getPhone() {
		// getter method for contact phone
		return phone;
	}
	
	@Override
	public String toString() {
		// method to convert contact info into String for file
		return "<contact><id>" + this.id + "</id><name>" + this.contactName.toUpperCase() + "</name><street>" + 
		this.street.toUpperCase() + "</street><city>" + this.city.toUpperCase() +
		"</city><state>" + this.state.toUpperCase() + "</state><zip>" +
		this.zip + "</zip><phone>" + this.phone + "</phone></contact>";		
	}	
} // end class Contact