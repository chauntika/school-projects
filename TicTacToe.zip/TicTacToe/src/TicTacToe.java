import java.util.Scanner;

/* Tic Tac Toe Game 
 * Simple Tic Tac Toe two player game utilizing AspectJ to act evaluate board to see
 * who won the game.
 * @author Chauntika Broggin 
*/
public class TicTacToe {
	// declare attributes
	private String playerCharacter = "x"; // represents current player's character X or O
	private boolean gameOver = false; // check if game is over
	private String[] board; // represents array of strings for printing board
	private String won = "---"; // represents the winner
	private boolean draw = false; // check if it is a draw
	
	public TicTacToe() {
		board = new String[9];
		for(int i = 0; i < 9; i++){
			board[i] = String.valueOf(i + 1);
		}
		printBoard();
	}
	
	public void printBoard() {
		// modified board interface look from 
		// https://www.geeksforgeeks.org/tic-tac-toe-game-in-java/ 
		// method to print 3X3 tic-tac-toe board
		// using lines, dashes, and numbers to represent spaces
		System.out.println("-------------");
		System.out.println("| " + board[0] + " | "  + board[1] +
				" | " + board[2] + " |");
		System.out.println("-------------");
		System.out.println("| " + board[3] + " | "  + board[4] +
				" | " + board[5] + " |");
		System.out.println("-------------");
		System.out.println("| " + board[6] + " | "  + board[7] +
				" | " + board[8] + " |");
		System.out.println("-------------");
		
	}
	
	public String[] getBoard() {
		return board;
	}
	
	public void changePlayerCharacter(){
		// method change character mark from x to o and vice versa
		if (playerCharacter == "x") {
			playerCharacter = "o";
		} else {
			playerCharacter = "x";
		}
	}
	
	public boolean checkEmptySlot(String boardSlot) {
		boolean slotEmpty;
		Integer arrayPosition = 0;	
		
		try {
		arrayPosition = Integer.parseInt(boardSlot) - 1; // getting array position number
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		
		// check if space is empty
		if (board[arrayPosition] == "x" || board[arrayPosition] == "o") {
			slotEmpty = false;			
		} else {
			slotEmpty = true;
		}	
		return slotEmpty;
	}
	
	public void getPlayerMove(String boardSlot) {		
		// method to get player's move	
		// Takes entered slot number value - 1 to get correct array position.
		// Uses entered boardSlot number to replace the entered number with player's mark.
		Integer arrayPosition = 0;	
		
		try {
			arrayPosition = Integer.parseInt(boardSlot) - 1; // getting array position number
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		
		if (checkEmptySlot(boardSlot)) {		
		board[arrayPosition] = getPlayerCharacter();	
		} else {			
				System.out.println("Slot full.");
		}		
		
		changePlayerCharacter();
					
	}	
	
	public boolean checkGameStatus() {
		// method to check if game is over
			
		// contents of each row
		String firstRow = board[0] + board[1] + board[2];
		String secondRow = board[3] + board[4] + board[5];
		String thirdRow = board[6] + board[7] + board[8];
	
		// contents of each column
		String firstColumn = board[0] + board[3] + board[6];
		String secondColumn = board[1] + board[4] + board[7];
		String thirdColumn = board[2] + board[5] + board[8];
	
		// content for each diagonal
		String leftRight = board[0] + board[4] + board[8];
		String rightLeft = board[2] + board[4] + board[6];
	
	if (firstRow.equalsIgnoreCase("xxx") || firstColumn.equalsIgnoreCase("xxx") || 
			secondRow.equalsIgnoreCase("xxx") || secondColumn.equalsIgnoreCase("xxx") || 
			thirdRow.equalsIgnoreCase("xxx") || thirdColumn.equalsIgnoreCase("xxx")) {
		gameOver = true;
		setWon("xxx");
	} else if (firstRow.equalsIgnoreCase("ooo") || firstColumn.equalsIgnoreCase("ooo") || 
			secondRow.equalsIgnoreCase("ooo") || secondColumn.equalsIgnoreCase("ooo") || 
			thirdRow.equalsIgnoreCase("ooo") || thirdColumn.equalsIgnoreCase("ooo")) {
		gameOver = true;
		setWon("ooo");
	} else if (leftRight.equalsIgnoreCase("xxx") || rightLeft.equalsIgnoreCase("xxx")) {
		gameOver = true;
		setWon("xxx");
	} else if (leftRight.equalsIgnoreCase("ooo") || rightLeft.equalsIgnoreCase("ooo")) {
		gameOver = true;
		setWon("ooo");
	}	
	
	// check for a draw
	String [] fullBoard = {firstRow, secondRow, thirdRow, firstColumn, secondColumn, thirdColumn};

	for (String element : fullBoard) {
		// checks to see if the board contains all x and o with no digits present
		// indicating a full board with not winner
		if (element.matches(".*\\\\d.*")) {
			setDraw(true);
			gameOver = true; // assign gameOver field true			
		}
		
	}	
	
	return gameOver; // return gameOver status
	}
	
	public String getPlayerCharacter() {
		return playerCharacter;
	}
	
	// set gameOver field
	public void setGameOver(boolean gameStatus) {
		gameOver = gameStatus;
	}
	
	// set won field
	public void setWon(String winner) {
		won = winner;
	}
	
	// set draw field
		public void setDraw(boolean tie) {
			draw = tie;
		}
	// get gameOver field value
	public boolean getGameOverValue() {
		return gameOver;
	}
	
	// get won field value
	public String getWon() {
		return won;
	}
	
	// get draw field value
		public boolean getDraw() {
			return draw;
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		TicTacToe gameOne = new TicTacToe();	
		System.out.println("TIC TAC TOE - Two player game.");
		System.out.println("--The first player uses the 'x' mark.\n");	
		
		Scanner slot = new Scanner(System.in);
		
		while (!gameOne.getGameOverValue()) {
			
			System.out.println("Current Player(" + gameOne.getPlayerCharacter() + 
					"): Enter slot number where to place next mark.");
			
			String desiredMove = slot.nextLine();
			
			if (gameOne.checkEmptySlot(desiredMove)) {
				gameOne.getPlayerMove(desiredMove);	
				gameOne.checkGameStatus();
			} else {
				System.out.println("Slot is full. Please try again.");
			}
			
			gameOne.printBoard(); // print board
		} 
		slot.close();				
	}
}